package Laboral;

public class Persona {
		
		static String nombre;
		static String dni;
		static char sexo;
		
		public static void main(String[] args) {
			System.out.println(nombre);
			System.out.println(dni);
			System.out.println(sexo);
			
		}
		
		public Persona(String nombre, String dni, char sexo) {
			Persona.nombre = nombre;
			Persona.dni = dni;
			Persona.sexo = sexo;
			
		}
		
		public Persona(String nombre, char sexo) {
			Persona.nombre = nombre;
			Persona.sexo = sexo;
			
		}


		public void setDni(String dni) {
			Persona.dni = dni;
		}
		
		
}
