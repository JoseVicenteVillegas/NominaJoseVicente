package Laboral;

public class CalcularNominas {

	public static void main(String[] args) {

		Persona james = new Persona("James Cosling", "32000032G", 'M');
		Persona ada = new Persona("Ada Lovelace","32000031R",'F');
		
		System.out.println(james);

		System.out.println(ada);

	}

}
