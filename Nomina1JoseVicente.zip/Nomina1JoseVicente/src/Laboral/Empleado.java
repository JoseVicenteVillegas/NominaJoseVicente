package Laboral;

public class Empleado extends Persona {

	private static int categoria;
	static int anyos;
	
	public static void main(String[] args) {
		System.out.println(categoria);
		System.out.println(anyos);

		
	}
	public Empleado(String nombre, String dni, char sexo) {
		super(nombre, dni, sexo);

	}

	public Empleado(String nombre, char dni, String sexo, int categoria, int anyos) {
		super(nombre, sexo, dni);
		Empleado.categoria = categoria;
		Empleado.anyos = anyos;
		
	}

	public int getCategoria() {
		return categoria;
	}

	public void setCategoria(int categoria) {
		Empleado.categoria = categoria;
	}

	public int getAnyos() {
		return anyos;
	}

	public void setAnyos(int anyos) {
		Empleado.anyos = anyos;
	}

	
}
