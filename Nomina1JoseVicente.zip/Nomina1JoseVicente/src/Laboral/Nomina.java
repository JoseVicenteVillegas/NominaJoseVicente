package Laboral;

public class Nomina extends Empleado {

	public Nomina(String nombre, char dni, String sexo, int categoria, int anyos) {
		super(nombre, dni, sexo, categoria, anyos);
	}

	private static final int SUELDO_BASE[] = {50000, 70000, 90000, 110000, 130000, 150000, 170000, 190000, 210000, 230000};

	int sueldo;
	
	public void Calcular_Sueldo() {

		
	}
		
	

}
